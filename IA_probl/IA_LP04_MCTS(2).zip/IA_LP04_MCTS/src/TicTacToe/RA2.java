package TicTacToe;

import java.util.HashSet;

public class RA2 {

	/**
	 * The "brain" of the Reactive Agent
	 * 
	 * @param board the Tic Tac Toe board to play on
	 */
	static void action(Board board) {
		int move = -1;
		move = possibleWin(board, board.getTurn());
		// nivel 0 - Verificar possivel vitoria
		if (move != -1) {
			board.move(move);
		} else {
			// nivel 1 - Verificar possivel vitoria do oponente
			Board.State sta;
			if (board.getTurn() == Board.State.X)
				sta = Board.State.O;
			else
				sta = Board.State.X;
			move = possibleWin(board, sta);
			if (move != -1) {
				board.move(move);
			} else {
				// nivel 2 - Verificar se e o primeiro move
				if (isFirstMove(board)) {
					board.move(firstMove(board));
				} else {
					// nivel 3 - verifica se podemos jogar no centro e se foi o adversario a jogar
					// primeiro
					if (isSecondMove(board)) {
						board.move(4);
					} else {
						// nivel 4 - verifica se o oponente tem uma possiblidade de fork
						if (possibleOpponentFork(board, sta)) {
							board.move(blockDia(board));
						} else {
							// nivel 5 - Se o centro estiver ocupado pelo adversario e se tenho um canto com possibilidade de completar a diagonal
							if (myPossibleFork(board, board.getTurn(), sta)) {
								board.move(completeDiagonal(board));
							} else {
								// nivel 6 - preenche outro canto que esteja livre
								if (viewBox(board, 8) || viewBox(board, 0) || viewBox(board, 2) || viewBox(board, 6)) {
									board.move(anotherCorner(board));
								}
								// nivel 7 - jogada random
								else {
									board.move(randomMove(board));
								}
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Function that see if the opponent (state) have the possibility to make a fork in a diagonal of a board
	 * @param board
	 * @param state
	 * @return true if that is verified, otherwise false
	 */
	private static boolean possibleOpponentFork(Board board, Board.State state) {
		Board.State[][] board2 = board.toArray();
		if ((board2[0][2] == state && board2[2][0] == state) || (board2[0][0] == state && board2[2][2] == state))
			return true;
		else
			return false;
	}

	/**
	 * Function that see if I (state) have the possibility to make a fork in a diagonal of a board, but the opponent had a center
	 * @param board
	 * @param state
	 * @return true if that is verified, otherwise false
	 */
	private static boolean myPossibleFork(Board board, Board.State state, Board.State opponent) {
		Board.State[][] board2 = board.toArray();
		if ((board2[0][2] == state && board2[2][0] == state && board2[1][1] == opponent)
				|| (board2[0][0] == state && board2[2][2] == state && board2[1][1] == opponent))
			return true;
		else
			return false;
	}

	/**
	 * Get a first place Blank, we call the function randomMove bc I just need a
	 * place to play
	 * 
	 * @param board the Tic Tac Toe board to play on
	 * @return return the index off a blank place or -1 if the board dont have blank
	 *         places.
	 */
	private static int randomMove(Board board) {
		Board.State[][] board2 = board.toArray();
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (board2[i][j] == Board.State.Blank) {
					return (i * 3) + j;
				}
			}
		}
		return -1;
	}
	
	/**
	 * Function that gives a indice to block a fork in diagonal
	 * @param board
	 * @return int - indice to block a fork
	 */
	private static int blockDia(Board board) {
		HashSet<Integer> freeMoves = board.getAvailableMoves();
		if (freeMoves.contains(1)) {
			return 1;
		} else if (freeMoves.contains(3)) {
			return 3;
		} else if (freeMoves.contains(5)) {
			return 5;
		} else if (freeMoves.contains(7)) {
			return 7;
		} else
			return -1;
	}

	/**
	 * Check if the place is blank (place = box )
	 * 
	 * @param board the Tic Tac Toe board to play on
	 * @param i     the index of a place that we want to check
	 * @return true if the place is blank, otherwise false
	 */
	private static boolean viewBox(Board board, int i) {
		HashSet<Integer> freeMoves = board.getAvailableMoves();
		return freeMoves.contains(i);
	}

	/**
	 * Give another corner that we can play
	 * 
	 * @param board the Tic Tac Toe board to play on
	 * @return the index of the corner to play
	 */
	private static int anotherCorner(Board board) {
		HashSet<Integer> freeMoves = board.getAvailableMoves();
		Board.State[][] board2 = board.toArray();
		if (board2[2][0] == board.getTurn()) {
			return betterCorner(board, freeMoves, 2 * 3 + 0);
		}
		if (board2[0][2] == board.getTurn()) {
			return betterCorner(board, freeMoves, 0 * 3 + 2);
		}
		if (board2[2][2] == board.getTurn()) {
			return betterCorner(board, freeMoves, 2 * 3 + 2);
		}
		if (board2[0][0] == board.getTurn()) {
			return betterCorner(board, freeMoves, 0 * 3 + 0);
		}
		//System.out.println("testeee");
		return randomCorners(board);
	}

	/**
	 * Give the better corner to play taking into account the board (the availables
	 * moves), and the corners with agent move
	 * 
	 * @param freeMoves the availables moves in the board
	 * @param i         the index of a corner with a agent move
	 * @return the index of the better corner to play
	 */
	private static int betterCorner(Board board, HashSet<Integer> freeMoves, int i) {
		if (i == 8) {
			if (freeMoves.contains(2)) {
				if (freeMoves.contains(1) && freeMoves.contains(5))
					return 2;
			}
			if (freeMoves.contains(6)) {
				if (freeMoves.contains(3) && freeMoves.contains(7))
					return 6;
			}
			if (freeMoves.contains(0))
				return 0;
		}

		if (i == 6) {
			if (freeMoves.contains(8)) {
				if (freeMoves.contains(7) && freeMoves.contains(5))
					return 8;
			}
			if (freeMoves.contains(0)) {
				if (freeMoves.contains(1) && freeMoves.contains(3))
					return 0;
			}
			if (freeMoves.contains(2))
				return 2;
		}

		if (i == 2) {
			if (freeMoves.contains(8)) {
				if (freeMoves.contains(7) && freeMoves.contains(5))
					return 8;
			}
			if (freeMoves.contains(0)) {
				if (freeMoves.contains(1) && freeMoves.contains(3))
					return 0;
			}
			if (freeMoves.contains(6))
				return 6;
		}

		if (i == 0) {
			if (freeMoves.contains(2)) {
				if (freeMoves.contains(1) && freeMoves.contains(5))
					return 2;
			}
			if (freeMoves.contains(6)) {
				if (freeMoves.contains(3) && freeMoves.contains(7))
					return 6;
			}
			if (freeMoves.contains(8))
				return 8;
		}
		return randomCorners(board);
	}

	/**
	 * Check if the player that plays with a state s can win the game with one more
	 * move
	 * 
	 * @param board the Tic Tac Toe board to play on
	 * @param s     the state of a player
	 * @return true if is possible, otherwise false
	 */
	private static int possibleWin(Board board, Board.State s) {
		int result;
		if ((result = checkColumns(board, s)) != -1) {
			// System.out.println("Coluna");
			return result;
		} else if ((result = checkRows(board, s)) != -1) {
			// System.out.println("Linha");
			return result;
		} else if ((result = checkDiagonalLtoR(board, s)) != -1) {
			// System.out.println("Dia LR");
			return result;
		} else if ((result = checkDiagonalRtoL(board, s)) != -1) {
			// System.out.println("Dia RL");
			return result;
		} else
			return -1;
	}

	/**
	 * Check all columns if they one have a place with 2 states s and one place with
	 * state blank
	 * 
	 * @param board the Tic Tac Toe board to play on
	 * @param s     the state that we want to check
	 * @return return the index of a place that have a black state if exist,
	 *         otherwise -1
	 */
	private static int checkColumns(Board board, Board.State s) {
		Board.State[][] board2 = board.toArray();

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (board2[j][i] == Board.State.Blank && board2[(j + 1) % 3][i] == s && board2[(j + 2) % 3][i] == s) {
					return ((j * 3) + i);
				}
			}
		}
		return -1;
	}

	/**
	 * Check all rows if they have 2 places with states s and one place with a blank
	 * state
	 * 
	 * @param board the Tic Tac Toe board to play on
	 * @param s     the state that we want to check
	 * @return return the index of a place that have a black state if exist,
	 *         otherwise -1
	 */
	private static int checkRows(Board board, Board.State s) {
		Board.State[][] board2 = board.toArray();

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (board2[i][j] == Board.State.Blank && board2[i][(j + 1) % 3] == s && board2[i][(j + 2) % 3] == s) {
					return ((i * 3) + j);
				}
			}
		}
		return -1;
	}

	/**
	 * Check the LeftToRight Diagonal if they have 2 places with states s and one
	 * place with a blank state
	 * 
	 * @param board the Tic Tac Toe board to play on
	 * @param s     the state that we want to check
	 * @return return the index of a place that have a black state if exist,
	 *         otherwise -1
	 */
	private static int checkDiagonalLtoR(Board board, Board.State s) {
		Board.State[][] board2 = board.toArray();
		if (board2[0][0] == Board.State.Blank && board2[1][1] == s && board2[2][2] == s) {
			return ((0 * 3) + 0);
		} else if (board2[1][1] == Board.State.Blank && board2[0][0] == s && board2[2][2] == s) {
			return ((1 * 3) + 1);
		} else if (board2[2][2] == Board.State.Blank && board2[1][1] == s && board2[0][0] == s) {
			return ((2 * 3) + 2);
		}
		return -1;
	}

	/**
	 * Check the RightToLeft Diagonal if they have 2 places with states s and one
	 * place with a blank state
	 * 
	 * @param board the Tic Tac Toe board to play on
	 * @param s     the state that we want to check
	 * @return return the index of a place that have a black state if exist,
	 *         otherwise -1
	 */
	private static int checkDiagonalRtoL(Board board, Board.State s) {
		Board.State[][] board2 = board.toArray();

		if (board2[0][2] == Board.State.Blank && board2[1][1] == s && board2[2][0] == s) {
			return ((0 * 3) + 2);
		} else if (board2[1][1] == Board.State.Blank && board2[0][2] == s && board2[2][0] == s) {
			return ((1 * 3) + 1);
		} else if (board2[2][0] == Board.State.Blank && board2[1][1] == s && board2[0][2] == s) {
			return ((2 * 3) + 0);
		}

		return -1;
	}

	/**
	 * Check if the board is empty (just have blank states), that give to agent the
	 * information if he is the first "player" to play
	 * 
	 * @param board the Tic Tac Toe board to play on
	 * @return true if that is verified, otherwise false
	 */
	private static boolean isFirstMove(Board board) {
		boolean result = true;
		Board.State[][] board2 = board.toArray();
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (board2[i][j] != Board.State.Blank)
					return false;
			}
		}
		return result;
	}

	/**
	 * Check if the board have 1 state and the center is blank that give to agent
	 * the information if he is the second "player" to play and can play in center
	 * 
	 * @param board the Tic Tac Toe board to play on
	 * @return true if that is verified, otherwise false
	 */
	private static boolean isSecondMove(Board board) {
		int count = 0;
		Board.State[][] board2 = board.toArray();
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (board2[i][j] != Board.State.Blank)
					count++;
			}
		}
		if (count == 1 && board2[1][1] == Board.State.Blank)
			return true;
		else
			return false;
	}

	/**
	 * Give 1 of an available corner of the board
	 * 
	 * @return the index of a corner
	 */
	private static int randomCorners(Board board) {
		HashSet<Integer> freeMoves = board.getAvailableMoves();
		if (freeMoves.contains(0))
			return 0;
		else if (freeMoves.contains(2))
			return 2;
		else if (freeMoves.contains(6))
			return 6;
		else if (freeMoves.contains(8))
			return 8;
		else
			return -1;
	}

	/**
	 * Give a place to play the first move
	 * 
	 * @return the index of a place
	 */
	private static int firstMove(Board board) {
		return randomCorners(board);
	}

	/**
	 * Give us a corner that will complete one diagonal
	 * 
	 * @param board the Tic Tac Toe board to play on
	 * @return the index of the corner
	 */
	private static int completeDiagonal(Board board) {
		Board.State[][] board2 = board.toArray();
		if (board2[2][0] == board.getTurn() && board2[0][2] == Board.State.Blank)
			return 2;
		else if (board2[0][2] == board.getTurn() && board2[2][0] == Board.State.Blank)
			return 6;
		else if (board2[0][0] == board.getTurn() && board2[2][2] == Board.State.Blank)
			return 8;
		else
			return 0;
	}

}
