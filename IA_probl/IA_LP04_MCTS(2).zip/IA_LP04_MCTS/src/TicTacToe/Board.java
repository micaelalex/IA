package TicTacToe;

import java.util.*;

/**
 * Represents the Tic Tac Toe board.
 */
public class Board implements Ilayout, Cloneable {

	static final int BOARD_WIDTH = 3;

	public enum State {
		Blank, X, O
	}

	private State[][] board;
	private State playersTurn;
	private State winner;
	private HashSet<Integer> movesAvailable;
	private int lastMove = -1;

	Random rand = new Random();

	private int moveCount;
	private boolean gameOver;

	public void setBoardArray(State[][] a) {
		this.board = a;
	}

	/**
	 * Construct the Tic Tac Toe board.
	 */
	Board() {
		board = new State[BOARD_WIDTH][BOARD_WIDTH];
		movesAvailable = new HashSet<>();
		reset();
	}

	/**
	 * Set the cells to be blank and load the available moves (all the moves are
	 * available at the start of the game).
	 */
	private void initialize() {
		for (int row = 0; row < BOARD_WIDTH; row++) {
			for (int col = 0; col < BOARD_WIDTH; col++) {
				board[row][col] = State.Blank;
			}
		}

		movesAvailable.clear();

		for (int i = 0; i < BOARD_WIDTH * BOARD_WIDTH; i++) {
			movesAvailable.add(i);
		}
	}

	/**
	 * Restart the game with a new blank board.
	 */
	void reset() {
		moveCount = 0;
		gameOver = false;
		playersTurn = State.X;
		winner = State.Blank;
		initialize();
	}

	/**
	 * Places an X or an O on the specified index depending on whose turn it is.
	 * 
	 * @param index the position on the board (example: index 4 is location (0, 1))
	 * @return true if the move has not already been played
	 */
	public boolean move(int index) {
		return move(index % BOARD_WIDTH, index / BOARD_WIDTH);
	}

	/**
	 * Places an X or an O on the specified location depending on who turn it is.
	 * 
	 * @param x the x coordinate of the location
	 * @param y the y coordinate of the location
	 * @return true if the move has not already been played
	 */
	private boolean move(int x, int y) {

		if (gameOver) {
			throw new IllegalStateException("TicTacToe is over. No moves can be played.");
		}

		if (board[y][x] == State.Blank) {
			board[y][x] = playersTurn;
		} else {
			return false;
		}

		moveCount++;
		movesAvailable.remove(y * BOARD_WIDTH + x);
		lastMove = y * BOARD_WIDTH + x;

		// The game is a draw.
		if (moveCount == BOARD_WIDTH * BOARD_WIDTH) {
			winner = State.Blank;
			gameOver = true;
		}

		// Check for a winner.
		checkRow(y);
		checkColumn(x);
		checkDiagonalFromTopLeft(x, y);
		checkDiagonalFromTopRight(x, y);

		playersTurn = (playersTurn == State.X) ? State.O : State.X;
		return true;
	}

	/**
	 * Check to see if the game is over (if there is a winner or a draw).
	 * 
	 * @return true if the game is over
	 */
	@Override
	public boolean isGameOver() {
		return gameOver;
	}

	/**
	 * Get a copy of the array that represents the board.
	 * 
	 * @return the board array
	 */
	State[][] toArray() {
		return board.clone();
	}

	/**
	 * Check to see who's turn it is.
	 * 
	 * @return the player who's turn it is
	 */
	public State getTurn() {
		return playersTurn;
	}

	/**
	 * Check to see who won.
	 * 
	 * @return the player who won (or Blank if the game is a draw)
	 */
	public State getWinner() {
		if (!gameOver) {
			throw new IllegalStateException("TicTacToe is not over yet.");
		}
		return winner;
	}

	/**
	 * Get the indexes of all the positions on the board that are empty.
	 * 
	 * @return the empty cells
	 */
	public HashSet<Integer> getAvailableMoves() {
		return movesAvailable;
	}

	/**
	 * Checks the specified row to see if there is a winner.
	 * 
	 * @param row the row to check
	 */
	private void checkRow(int row) {
		for (int i = 1; i < BOARD_WIDTH; i++) {
			if (board[row][i] != board[row][i - 1]) {
				break;
			}
			if (i == BOARD_WIDTH - 1) {
				winner = playersTurn;
				gameOver = true;
			}
		}
	}

	/**
	 * Checks the specified column to see if there is a winner.
	 * 
	 * @param column the column to check
	 */
	private void checkColumn(int column) {
		for (int i = 1; i < BOARD_WIDTH; i++) {
			if (board[i][column] != board[i - 1][column]) {
				break;
			}
			if (i == BOARD_WIDTH - 1) {
				winner = playersTurn;
				gameOver = true;
			}
		}
	}

	/**
	 * Check the left diagonal to see if there is a winner.
	 * 
	 * @param x the x coordinate of the most recently played move
	 * @param y the y coordinate of the most recently played move
	 */
	private void checkDiagonalFromTopLeft(int x, int y) {
		if (x == y) {
			for (int i = 1; i < BOARD_WIDTH; i++) {
				if (board[i][i] != board[i - 1][i - 1]) {
					break;
				}
				if (i == BOARD_WIDTH - 1) {
					winner = playersTurn;
					gameOver = true;
				}
			}
		}
	}

	/**
	 * Check the right diagonal to see if there is a winner.
	 * 
	 * @param x the x coordinate of the most recently played move
	 * @param y the y coordinate of the most recently played move
	 */
	private void checkDiagonalFromTopRight(int x, int y) {
		if (BOARD_WIDTH - 1 - x == y) {
			for (int i = 1; i < BOARD_WIDTH; i++) {
				if (board[BOARD_WIDTH - 1 - i][i] != board[BOARD_WIDTH - i][i - 1]) {
					break;
				}
				if (i == BOARD_WIDTH - 1) {
					winner = playersTurn;
					gameOver = true;
				}
			}
		}
	}

	/**
	 * Get a deep copy of the Tic Tac Toe board.
	 * 
	 * @return an identical copy of the board
	 */
	public Board getDeepCopy() {
		Board board = new Board();

		for (int i = 0; i < board.board.length; i++) {
			board.board[i] = this.board[i].clone();
		}

		board.playersTurn = this.playersTurn;
		board.winner = this.winner;
		board.movesAvailable = new HashSet<>();
		board.movesAvailable.addAll(this.movesAvailable);
		board.moveCount = this.moveCount;
		board.gameOver = this.gameOver;
		return board;
	}

	/**
	 * Funcao que permite transformar a Board numa string que a melhor representa.
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		for (int y = 0; y < BOARD_WIDTH; y++) {
			for (int x = 0; x < BOARD_WIDTH; x++) {

				if (board[y][x] == State.Blank) {
					sb.append("-");
				} else {
					sb.append(board[y][x].name());
				}
				sb.append(" ");

			}
			if (y != BOARD_WIDTH - 1) {
				sb.append("\n");
			}
		}

		return new String(sb);
	}

	/**
	 * Funcao que permite criar os sucessores deste Board
	 */
	@Override
	public List<Ilayout> children() {
		// TODO Auto-generated method stub
		List<Ilayout> children = new ArrayList<>();
		for (int place : movesAvailable) {
			Board a = this.getDeepCopy();
			// System.out.println(place);
			a.move(place);
			children.add(a);
		}
		return children;
	}

	/**
	 * Funcao que permite comparar dois Boards (Ilayouts)
	 */
	@Override
	public boolean equal(Ilayout l) {
		// TODO Auto-generated method stub
		Board a = (Board) l;
		for (int i = 0; i < BOARD_WIDTH; i++) {
			for (int j = 0; j < BOARD_WIDTH; j++) {
				if (this.board[i][j] != a.board[i][j]) {
					return false;
				}
			}

		}
		return true;
	}

	/**
	 * Funcao que retorna o valor de avaliacao do jogo final dependendo do jogador
	 * thePlayer.
	 * 
	 * @param thePlayer
	 * @return
	 */
	public double getW(Board.State thePlayer) {
		// TODO Auto-generated method stub
		if (thePlayer == this.winner) {
			return 1;
		} else if (this.winner == State.Blank) {
			return 0.7;
		} else
			return 0;
	}

	/**
	 * Funcao que permite simular ate ao termino do Jogo e retornar um valor
	 * dependendo do quao favoravel ee para um determinado jogador.
	 */
	@Override
	public double simulation(int player) {
		// TODO Auto-generated method stub
		Board.State state = this.intToState(player);
		if (this.isGameOver()) {
			return this.getW(state);
		}
		Board simulationBoard = this.getDeepCopy();
		while (!simulationBoard.isGameOver()) {
			simulationBoard.move(simulationBoard.randomMove());
		}
		return simulationBoard.getW(state);
	}

	/**
	 * Funcao que permite fazer uma jogada aleatoria no board, atrav�s das jogadas
	 * disponiveis, em que ee selecionada aleatoriamente uma delas.
	 * 
	 * @return
	 */
	private int randomMove() {
		ArrayList<Integer> array = this.HMtoArray();
		// int Min = 0;
		int Max = array.size();
		int move = rand.nextInt(Max);
		return array.get(move);
	}

	/**
	 * Funcao que permite transformar os valores do HashMap movesAvailable para um
	 * ArrayList.
	 * 
	 * @return ArrayList
	 */
	private ArrayList<Integer> HMtoArray() {
		ArrayList<Integer> a = new ArrayList<Integer>();

		for (int place : movesAvailable) {
			a.add(place);
		}
		return a;
	}

	/**
	 * Funcao que permite receber um inteiro que representa o jogador a jogar neste
	 * turno.
	 */
	@Override
	public int getPlayer() {
		// TODO Auto-generated method stub
		if (this.playersTurn == Board.State.X)
			return 1;
		else
			return 2;
	}

	/**
	 * Funcao que permite transformar um inteiro p que representa um jogador para um
	 * estado deste Board.
	 * 
	 * @param p - inteiro
	 * @return
	 */
	public Board.State intToState(int p) {
		if (p == 1)
			return Board.State.X;
		else
			return Board.State.O;
	}

	/**
	 * Funcao que permite determinar qual foi o ultimo jogador a jogar.
	 */
	@Override
	public int getLastMove() {
		// TODO Auto-generated method stub
		return lastMove;
	}

}
