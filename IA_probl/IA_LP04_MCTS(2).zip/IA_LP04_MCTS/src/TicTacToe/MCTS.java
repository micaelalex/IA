package TicTacToe;

import java.util.*;

public class MCTS {

	private final static double C = Math.sqrt(2);
	private int player = 0;

	/**
	 * Classe que representa o No (configura�ao/estado) da "arvore", nele iremos ter
	 * varios atributos importantes para a manipulacao de nos sucessores e ate para
	 * "estatisticas" necessarias para o MCTS
	 * Note: A classe deveria de ser privada, mas esta como publica para os testes unitarios
	 */
	public class Node {

		/**
		 * Atributos da classe node: numberOfWins representa o numero de vitorias,
		 * numberOfsimulations representa o numero de simulacoes, o layout representa a
		 * confuguracao deste no, o father ee o no pai deste no, e o children ee os
		 * filhos/sucessores deste no
		 *
		 */
		private double numberOfWins = 0;
		private double numberOfSimulations = 0;
		private Ilayout layout;
		private Node father;
		private List<Node> children;

		/**
		 * Construtor da classe Node que recebe um Ilayout e outro Node que sera o pai
		 * deste.
		 * 
		 * @param l - Ilayour que representa a configuracao
		 * @param n - No pai
		 */
		public Node(Ilayout l, Node n) {
			layout = l;
			father = n;
			children = new ArrayList<>();
		}

		/**
		 * Funcao que cria os nodes sucessores com auxilio da funcao
		 * children() do Ilayout
		 */
		public void sucs() {
			List<Ilayout> a = new ArrayList<>();
			a = this.getLayout().children();
			if (a != null) {
				for (Ilayout son : a) {
					children.add(new Node(son, this));
				}
			}
		}

		/**
		 * Funcao que permite representar o node em string
		 */
		public String toString() {
			return layout.toString();
		}

		/**
		 * Funcao para retornar o layout deste node.
		 * 
		 * @return layout
		 */
		public Ilayout getLayout() {
			return layout;
		}

		/**
		 * Funcao para retornar o pai deste node.
		 * 
		 * @return father
		 */
		public Node getFather() {
			return father;
		}

		/**
		 * Funcao que retorna a lista com os filhos/sucessores deste node
		 * 
		 * @return children
		 */
		public List<Node> getChildren() {
			return children;
		}

		/**
		 * Funcao que retorna o numero de vitorias deste node
		 * 
		 * @return numberOfWins
		 */
		public double getWins() {
			return numberOfWins;
		}

		/**
		 * Funcao que permite acrescentar uma quantidade (dp) de vitoiras a este node
		 * 
		 * @param dp
		 */
		public void setWins(double dp) {
			numberOfWins += dp;
		}

		/**
		 * Funcao que permite acresentar um numero (s) de simulacoes a este node
		 * 
		 * @param s
		 */
		public void setSimulations(int s) {
			numberOfSimulations += s;
		}

		/**
		 * Funcao que retorna o numeor de simulacoes deste node
		 * 
		 * @return numberOfSimulations
		 */
		public double getSimulations() {
			return numberOfSimulations;
		}

	}

	/**
	 * Esta funcao ee o cerebro do algoritmo, ou seja, e aqui que iremos executar
	 * sucessivamente as 4 fases (selecao, expansao, simulacao e retropropagacao)
	 * Este inicialmente recebe um Ilayout e apartir dai cria um node com esse
	 * layout e executa o algoritmo ate um determinado recurso (neste caso 5000
	 * execucoes do while)
	 * 
	 * @param l - O Ilayout
	 */
	public void MctsSearch(Ilayout l) {
		Node root = new Node(l, null);
		this.player = l.getPlayer();
		//Long duration = (long) 0;
		//long startTime = System.nanoTime();
		int count = 0;
		while (count < 5000) {
			// System.out.println(count);
			List<Node> tp = TreePolicy(root);
			for (Node son : tp) {
				double dp = DefaultPolicy(son);
				Backup(son, dp);
			}
			count++;
			//long endTime = System.nanoTime();
			//duration = TimeUnit.SECONDS.convert((endTime - startTime), TimeUnit.NANOSECONDS);
			// System.out.println(duration);
		}
		// System.out.println(count);
		l.move(this.BestChild(root).getLayout().getLastMove());

	}

	/**
	 * A funcao TreePolicy recebe um node r, e retorna uma lista com todos os
	 * filhos/sucessores do node r. Nesta funcao ele verifica se o no r tem filhos
	 * ou se j� ainda nao acabou o jogo, caso isso aconteca ele vai percorrer todos
	 * os filhos e encontrar o melhor. Caso esse filho tenha filhos tbm, ele volta a
	 * repetir o processo. Isto so acaba ate chegar a um no sem filhos ou em que o
	 * estado ee gameOver Caso chegue a um estado sem filhos e que nao ee gameOver
	 * ele chama a funcao sucs() para gerar os sucessores desse filho. Caso
	 * estejamos perante um Ilayout em que esta gameOver ele retorna o pai desse
	 * node.
	 * 
	 * @param r - Node inicial
	 * @return List<Node> - que contem os nos filhos ou o no pai caso seja gameOver;
	 */
	private List<Node> TreePolicy(Node r) {
		Node actual = r;
		while (actual.getChildren().size() > 0 && !actual.getLayout().isGameOver()) { // --------
			// System.out.println(actual.getLayout());
			// System.out.println(actual.getChildren().size());
			actual = BestChild(actual);
			// System.out.println("Mudou o actual para ->");
			// System.out.println(actual.getLayout());
			// System.out.println(actual.getChildren().size());
		}
		//if (actual == null) {
			// System.out.println("nuulllll");
		//}
		if (actual.getLayout().isGameOver()) {
			List<Node> a = new ArrayList<>();
			a.add(actual.getFather());
			return a;
		} else {
			actual.sucs();
			return actual.getChildren();
		}
	}

	/**
	 * Funcao que permite decidir qual o melhor filho de um Node R. Esta funcao
	 * verifica para cada filho a sua estimativa atual, e retorna o que tiver
	 * melhor.
	 * 
	 * @param r - Node inicial
	 * @return bestChild;
	 */
	public Node BestChild(Node r) {
		Node bestChild = r;
		double bestValue = Integer.MIN_VALUE;
		for (Node child : r.getChildren()) {
			double actualValue = BEAW(child);
			if (actualValue > bestValue) {
				// System.out.println(actualValue + " -> " + bestValue);
				bestValue = actualValue;
				bestChild = child;
			}
		}
		return bestChild;
	}

	/**
	 * Funcao que permite a partir de um node calcular a sua estimativa actual com
	 * ajuda da formula estudada.
	 * 
	 * @param actual - node inicial
	 * @return
	 */
	public double BEAW(Node actual) {
		return ((actual.getWins() / actual.getSimulations())
				+ (C * Math.sqrt((Math.log(actual.getFather().getSimulations()) / actual.getSimulations()))));
	}

	/**
	 * Funcao que permite realizar uma simulacao deste node s, para obtermos um
	 * gameOver e estipularmos para esse no uma estimativa inicial e retorna um
	 * valor que podera representar uma vitoria, empate ou derrota.
	 * 
	 * @param s - node inicial
	 * @return double - valor que representa se foi positiva ou nao a simulacao.
	 */
	public double DefaultPolicy(Node s) {
		return s.getLayout().simulation(this.player);
	}

	/**
	 * Funcao que Desde um Node s, ate ao node root vai alterando o numero de
	 * vitorias acresentando o dp, e aumentando o numero de simulacoes para mais uma
	 * em cada node ate ao root.
	 * 
	 * @param s  - node inicial
	 * @param dp - valor acresentar ao numero de vitorias de cada node.
	 */
	public void Backup(Node s, double dp) {
		// int wins = (int) dp;
		Node actual = s;
		while (actual != null) {
			actual.setWins(dp);
			actual.setSimulations(1);
			actual = actual.getFather();
		}
	}

}
