package TicTacToe;

import static org.junit.Assert.*;

import org.junit.Test;

public class MCTS_JUnitTest {

	@Test
	public void testMCTS() {
		MCTS algMcts = new MCTS();
		Board b = new Board();
		algMcts.MctsSearch(b);
		String compare = "- - - \n- X - \n- - - ";
		assertEquals(b.toString(), compare);
	}

	@Test
	public void testSelection() {
		MCTS algMcts = new MCTS();
		Board b = new Board();
		MCTS.Node sel = algMcts.new Node(b, null);
		sel.sucs();
		MCTS.Node BC = null;
		for (int i = 0; i < sel.getChildren().size(); i++) {
			if (i != 6) {
				sel.getChildren().get(i).setSimulations(10);
				sel.getChildren().get(i).setWins(2);
				sel.setWins(2);
			} else {
				sel.getChildren().get(i).setSimulations(10);
				sel.getChildren().get(i).setWins(9);
				sel.setWins(9);
				BC = sel.getChildren().get(i);
			}
			sel.setSimulations(10);
		}
		// System.out.println(BC.toString());
		// System.out.println(algMcts.BestChild(sel));
		assertEquals(BC.toString(), algMcts.BestChild(sel).toString());
	}

	@Test
	public void testExpansion() {
		MCTS algMcts = new MCTS();
		Board b = new Board();
		MCTS.Node sel = algMcts.new Node(b, null);
		sel.sucs();
		assertEquals(sel.getChildren().size(), 9);
	}

	/**
	 * Como ee uma simulacao nunca se sabera o valor ao certo, o que podemos dizer
	 * ee que este esta entre 3 valores
	 */
	@Test
	public void testSimulation() {
		MCTS algMcts = new MCTS();
		Board b = new Board();
		MCTS.Node sel = algMcts.new Node(b, null);
		double sim = algMcts.DefaultPolicy(sel);
		if (sim == 1) {
			assertEquals(sim, 1, 0.01);
		} else if (sim == 0.7) {
			assertEquals(sim, 0.7, 0.01);
		} else {
			assertEquals(sim, 0, 0.01);
		}
	}
	
	@Test
	public void testBackPropagation() {
		MCTS algMcts = new MCTS();
		Board b = new Board();
		MCTS.Node sel = algMcts.new Node(b, null);
		sel.sucs();
		double result =0;
		for(int i=0;i<sel.getChildren().size();i++) {
			double teste = algMcts.DefaultPolicy(sel.getChildren().get(i));
			result+=teste;
			algMcts.Backup(sel.getChildren().get(i), teste);
		}
		assertEquals(sel.getWins(), result, 0.01);
		assertEquals(sel.getSimulations(), sel.getChildren().size(), 0.01);
		
	}

}
