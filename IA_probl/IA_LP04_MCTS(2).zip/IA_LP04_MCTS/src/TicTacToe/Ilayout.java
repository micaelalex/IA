package TicTacToe;

import java.util.List;

public interface Ilayout {

	/**
	 * @return the children of the receiver.
	 */
	List<Ilayout> children();

	/**
	 * @return true if the receiver equals the argument l; return false otherwise.
	 */
	boolean equal(Ilayout l);;

	/**
	 * @return make a simulation of a game to get a end of a game
	 */
	double simulation(int player);

	/**
	 * @return the number of the player
	 */
	int getPlayer();
	
	/**
	 * @return true if the game is over (i.e. we already have a result to the game).
	 */
	boolean isGameOver();
	
	/**
	 * @return true is the index is a possible move in Ilayout 
	 */
	boolean move(int index);
	
	/**
	 * @return the player who played in last.
	 */
	int getLastMove();
	
	
}
