import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.Test;

public class UnitTests {

	/*
	@Test
	public void test1_A_Star() {
		int result = 0;
		A_Star s = new A_Star();
		Iterator<A_Star.State> it = s.solve(new Board15P("123456789ABCDEF0"), new Board15P("23401567ABC89DEF"));
		while (it.hasNext()) {
			A_Star.State i = it.next();
			// System.out.println(i);
			if (!it.hasNext())
				result = (int) i.getG();
		}
		System.out.println("TESTE 1 A_STAR = gerados: " + s.gerados  + "   expandidos: " + s.expandidos);
		assertEquals(result, 15);
	}
	
	@Test
	public void test1_IDA_Star() {
		int result = 0;
		IDA_Star s = new IDA_Star();
		Iterator<IDA_Star.State> it = s.ida_star(new Board15P("123456789ABCDEF0"), new Board15P("23401567ABC89DEF"));
		while (it.hasNext()) {
			IDA_Star.State i = it.next();
			// System.out.println(i);
			if (!it.hasNext())
				result = (int) i.getG();
		}
		System.out.println("TESTE 1 IDA_STAR = gerados: " + s.gerados  + "   expandidos: " + s.expandidos);
		assertEquals(result, 15);
	}
	/*
	@Test
	public void test6_IDA_Star() {
		int result = 0;
		IDA_Star s = new IDA_Star();
		Iterator<IDA_Star.State> it = s.ida_star(new Board15P("123456789ABCDEF0"), new Board15P("123456089A7BDEFC"));
		while (it.hasNext()) {
			IDA_Star.State i = it.next();
			// System.out.println(i);
			if (!it.hasNext())
				result = (int) i.getG();
		}
		System.out.println("TESTE 6 IDA_STAR = gerados: " + s.gerados  + "   expandidos: " + s.expandidos);
		assertEquals(result, 3);
	}*/
	
	/*
	@Test
	public void test2_A_Star() {
		int result = 0;
		A_Star s = new A_Star();
		Iterator<A_Star.State> it = s.solve(new Board15P("23471568ABCF09DE"), new Board15P("123456789ABCDEF0"));
		while (it.hasNext()) {
			A_Star.State i = it.next();
			// System.out.println(i);
			if (!it.hasNext())
				result = (int) i.getG();
		}
		System.out.println("TESTE 2 A_STAR = gerados: " + s.gerados  + "   expandidos: " + s.expandidos);
		assertEquals(result, 21);
	} 
	
	@Test
	public void test2_IDA_Star() {
		int result = 0;
		IDA_Star s = new IDA_Star();
		Iterator<IDA_Star.State> it = s.ida_star(new Board15P("23471568ABCF09DE"), new Board15P("123456789ABCDEF0"));
		while (it.hasNext()) {
			IDA_Star.State i = it.next();
			// System.out.println(i);
			if (!it.hasNext())
				result = (int) i.getG();
		}
		System.out.println("TESTE 2 IDA_STAR = gerados: " + s.gerados  + "   expandidos: " + s.expandidos);
		assertEquals(result, 21);
	}*/
	
	@Test
	public void test3_IDA_Star() {
		int result = 0;
		IDA_Star s = new IDA_Star();
		Iterator<IDA_Star.State> it = s.ida_star(new Board15P("2F1C856B49A73ED0"), new Board15P("123456789ABCDEF0"));
		while (it.hasNext()) {
			IDA_Star.State i = it.next();
			// System.out.println(i);
			if (!it.hasNext())
				result = (int) i.getG();
		}
		System.out.println("TESTE 3 IDA_STAR = gerados: " + s.gerados  + "   expandidos: " + s.expandidos);
		assertEquals(result, 56);
	}/*
	
	@Test
	public void test4_IDA_Star() {
		int result = 0;
		IDA_Star s = new IDA_Star();
		Iterator<IDA_Star.State> it = s.ida_star(new Board15P("2F1C0856B49A73ED"), new Board15P("123456789ABCDEF0"));
		while (it.hasNext()) {
			IDA_Star.State i = it.next();
			// System.out.println(i);
			if (!it.hasNext())
				result = (int) i.getG();
		}
		System.out.println("TESTE 4 IDA_STAR = gerados: " + s.gerados  + "   expandidos: " + s.expandidos);
		assertEquals(result, 59);
	}
	@Test
	public void test5_IDA_Star() {
		int result = 0;
		IDA_Star s = new IDA_Star();
		Iterator<IDA_Star.State> it = s.ida_star(new Board15P("123456789ABCDEF0"), new Board15P("0FEDCBA987654321"));
		while (it.hasNext()) {
			IDA_Star.State i = it.next();
			// System.out.println(i);
			if (!it.hasNext())
				result = (int) i.getG();
		}
		System.out.println("TESTE 5 IDA_STAR = gerados: " + s.gerados  + "   expandidos: " + s.expandidos);
		assertEquals(result, 78);
	}
	/*
	@Test
	public void test3_A_Star() {
		int result = 0;
		A_Star s = new A_Star();
		Iterator<A_Star.State> it = s.solve(new Board15P("2F1C856B49A73ED0"), new Board15P("123456789ABCDEF0"));
		while (it.hasNext()) {
			A_Star.State i = it.next();
			// System.out.println(i);
			if (!it.hasNext())
				result = (int) i.getG();
		}
		System.out.println("TESTE 3 A_STAR = gerados: " + s.gerados  + "   expandidos: " + s.expandidos);
		assertEquals(result, 56);
	}
	 
	@Test
	public void test4_A_Star() {
		int result = 0;
		A_Star s = new A_Star();
		Iterator<A_Star.State> it = s.solve(new Board15P("2F1C0856B49A73ED"), new Board15P("123456789ABCDEF0"));
		while (it.hasNext()) {
			A_Star.State i = it.next();
			// System.out.println(i);
			if (!it.hasNext())
				result = (int) i.getG();
		}
		System.out.println("TESTE 4 A_STAR = gerados: " + s.gerados  + "   expandidos: " + s.expandidos);
		assertEquals(result, 59);
	}
	
	@Test
	public void test5_A_Star() {
		int result = 0;
		A_Star s = new A_Star();
		Iterator<A_Star.State> it = s.solve(new Board15P("123456789ABCDEF0"), new Board15P("0FEDCBA987654321"));
		while (it.hasNext()) {
			A_Star.State i = it.next();
			// System.out.println(i);
			if (!it.hasNext())
				result = (int) i.getG();
		}
		System.out.println("TESTE 5 A_STAR = gerados: " + s.gerados  + "   expandidos: " + s.expandidos);
		assertEquals(result, 78);
	}
	*/

}
