import java.util.*;

public class Main {

	/**
	 * Funcao main que le os dois inputs (o do tabuleiro inicial e o objetivo) da
	 * consola e inicializa os Boards com eles. Executando assim o algortimo de IDS.
	 * Caso ha-ja solucao ele vai desde o n� inicial e objetivo acabando por
	 * retornar a profundidade(o caminho mais curto).
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		//IDS s = new IDS();
		A_Star teste = new A_Star();
		Board15P first = new Board15P(sc.next());
		Board15P second = new Board15P(sc.next());
		// long startTime = System.nanoTime();
		Iterator<A_Star.State> it = teste.solve(first, second);
		// Iterator<BestFirst.State> it2 =teste.solve(first, second);
		// long endTime = System.nanoTime();
		if (it == null)
			System.out.println("no solution was found");
		else {
			while (it.hasNext()) {
				A_Star.State i = it.next();
				// System.out.println(i);
				if (!it.hasNext())
					System.out.println((int) i.getG());
			}
		}
		// long totalTime = (endTime - startTime)/1000000000;
		// System.out.println(totalTime);
		sc.close();
	}

}

