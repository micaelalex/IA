import java.util.*;

/**
 * Classe para implementar o algoritmo BestFirst
 * 
 * @author GR05
 *
 */
public class A_Star {
	/**
	 * A classe State ira representar cada no da arvore de procura
	 * 
	 * @author GR05
	 *
	 */
	static class State {
		// O objeto Ilayout que o no ira ter
		private Ilayout layout;
		// O pai deste no
		private State father;
		// A profundidade do no
		private double g;
		//
		private double h =-1;

		/**
		 * Construtor do State que dado um Ilayout l, e um State n cria um novo State,
		 * sendo l o atributo layout desse no e o n sera o pai desse o
		 * 
		 * @param l
		 * @param n
		 */
		public State(Ilayout l, State n) {
			layout = l;
			father = n;
			if (father != null)
				g = father.g + l.getG();
			else
				g = 0.0;
		}
		
		public double getH(Ilayout goal) {
			if(this.h==-1) {
				this.h=this.getLayout().getH(goal) +this.g;
				return this.h;
			} else
				return this.h;
		}

		/**
		 * Funcao que da print ao State da forma desejada, neste caso o mesmo que o
		 * Ilayout em questao
		 */
		public String toString() {
			return layout.toString();
		}

		/**
		 * Retorna o atributo g do no (State)
		 * 
		 * @return g
		 */
		public double getG() {
			return g;
		}

		/**
		 * Retorna o layout do State
		 * 
		 * @return layout
		 */
		public Ilayout getLayout() {
			return layout;
		}

		/**
		 * Retorna o pai desse State
		 * 
		 * @return father
		 */
		public State getFather() {
			return father;
		}


	}

	/**
	 * Atributos referentes a classe BestFirst: -Uma lista com prioridade para a
	 * lista dos abertos (aqueles que ainda nao foram testados). -Uma HashMap para a
	 * lista dos fechados (aqueles queja foram testados). -O Ilayout objetivo da
	 * procura -E dois inteiros so para saber o numero de nos gerados e expandidos
	 * durante a execucao do algoritmo.
	 */
	protected Queue<State> abertos;
	private Map<String, State> fechados;
	private State actual;
	private Ilayout objective;
	public int gerados = 0;
	public int expandidos = 0;

	/**
	 * A partir de um State n, retorna uma lista de State em que dentro delas estao
	 * os filhos do State n.
	 * 
	 * @param n
	 * @return sucs - lista com os filhos de n
	 */
	final private List<State> sucessores(State n) {
		List<State> sucs = new ArrayList<>();
		List<Ilayout> children = n.layout.children();
		for (Ilayout e : children) {
			// if (n.father == null || !e.equals(n.father.layout)) {
			if (n.father == null || !e.isGoal(n.father.layout)) {
				State nn = new State(e, n);
				sucs.add(nn);
			}
		}
		return sucs;
	}

	/**
	 * Funcao que retorna uma lista por ordem desde o State que desejamos, ate ao
	 * State do topo da arvore. Assim teremos uma sequencia de States desde o State
	 * do topo da arvore ate ao State em questao
	 * 
	 * @param begin
	 * @return result - a lista com essa sequencia
	 */
	final private List<State> sequence(State begin) {
		State pre = begin;
		List<State> result = new ArrayList<>();
		while (pre != null) {
			result.add(0, pre);
			pre = pre.getFather();
		}
		return result;
	}

	/**
	 * Funcao que implementa e executa o algoritmo BF. que deste um Ilayout inicial,
	 * procura um caminho ate o Ilayout Goal
	 * 
	 * @param s    - Ilayout que temos
	 * @param goal - Ilayout que desejamos
	 * @return Um Iterator<State> caso encontre a solucao com o caminho desde o s
	 *         ate ao goal, caso contrario retorna null
	 */
	final public Iterator<State> solve(Ilayout s, Ilayout goal) {
		int sum = 0; 
		objective = goal;
		gerados++;
		State initial = new State(s, null);
		Queue<State> abertos = new PriorityQueue<>(10, (s1, s2) -> (int) Math.signum(s1.getH(goal) - s2.getH(goal)));
		Map<String, State> fechados = new HashMap<>();
		abertos.add(initial);
		List<State> sucs;
		// TO BE COMPLETED
		while (true) {
			sum++;
			//System.out.println(sum );
			if (abertos.isEmpty()) {
				return null;
				/* throw exception */}
			actual = abertos.poll();
			//System.out.println(actual.getG() + "   "  + actual.getH(goal));
			if (actual.getLayout().isGoal(objective)) {
				{
					return this.sequence(actual).iterator();
				}

			} else {
				expandidos++;
				sucs = sucessores(actual);
				fechados.put(actual.toString(), actual);
				gerados += sucs.size();
				for (State f : sucs) {
					// gerados++;
					if (!fechados.containsKey(f.toString())) {
						abertos.add(f);
					} else
						expandidos++;
				}
			}
		}
	}
}
