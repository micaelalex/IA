import java.util.ArrayList;
import java.util.List;

/**
 * Classe do tabuleiro de 15 pe�as
 * 
 * @author Grupo 05
 *
 */
public class Board15P implements Ilayout, Cloneable {
	// a dim ee a largura do tabuleiro, neste caso 4 e a matriz board ira guardar os
	// valores de cada posicao do tabuleiro, e ainda o h que ee a o valor heuristico
	// deste Board
	private static final int dim = 4;
	private char board[][];
	private double h=-1;

	/**
	 * Construtor da classe que so inicializa a matriz vazia
	 */
	public Board15P() {
		board = new char[dim][dim];
		h=-1;
	}

	/**
	 * Construtor da classe que recebe como input uma string, que ira dispor da
	 * ordem do tabuleiro, mas so se a string tiver dim*dim=16 char's nela. Caso
	 * contrario lanca uma excecao
	 * 
	 * @param str
	 * @throws IllegalStateException
	 */
	public Board15P(String str) throws IllegalStateException {
		if (str.length() != dim * dim)
			throw new IllegalStateException("Invalid arg in Board constructor");
		board = new char[dim][dim];
		h = -1;
		int si = 0;
		for (int i = 0; i < dim; i++)
			for (int j = 0; j < dim; j++)
				board[i][j] = str.charAt(si++);
	}

	/**
	 * Funcao que a partir de um Board, cria outro igual.
	 * 
	 * @return a - o Board clonado
	 */
	public Board15P myClone() {
		Board15P a = new Board15P();
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
				a.board[i][j] = this.board[i][j];
			}
		}
		return a;
	}

	/**
	 * Funcao para retornar a matriz board do objeto
	 * 
	 * @return this.board
	 */
	public char[][] getBoard() {
		return this.board;
	}

	/**
	 * FFuncao para alterar um valor da matriz board do objeto. O parametro i
	 * corresponde a linha da matriz a mudar, o j a coluna e o x corresponde o valor
	 * a alterar
	 * 
	 * @param i
	 * @param j
	 * @param x
	 */
	public void setBoard(int i, int j, char x) {
		// System.out.println(board[i][j]);
		this.board[i][j] = x;
		// System.out.println(board[i][j]);
	}

	/**
	 * Funcao do Ilayout para criar os filhos do Objeto
	 */
	@Override
	public List<Ilayout> children() {
		// TODO Auto-generated method stub
		List<Ilayout> children = new ArrayList<>();
		int a = -10;
		int b = -10;
		outerloop: for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
				if (this.board[i][j] == '0') {
					a = i;
					b = j;
					break outerloop;
				}
			}
		}
		if (a - 1 >= 0 && a - 1 < dim) {
			Board15P son = this.myClone();
			// System.out.println(son);
			son.setBoard(a - 1, b, '0');
			son.setBoard(a, b, this.board[a - 1][b]);
			// System.out.println(son);
			children.add(son);
			// System.out.println(children.get(children.size()-1));
		}
		if (a + 1 >= 0 && a + 1 < dim) {
			Board15P son = this.myClone();
			// System.out.println(son);
			son.setBoard(a + 1, b, '0');
			son.setBoard(a, b, this.board[a + 1][b]);
			// System.out.println(son);
			children.add(son);
			// System.out.println(children.get(children.size()-1));
		}
		if (b - 1 >= 0 && b - 1 < dim) {
			Board15P son = this.myClone();
			// System.out.println(son);
			son.setBoard(a, b - 1, '0');
			son.setBoard(a, b, this.board[a][b - 1]);
			// System.out.println(son);
			children.add(son);
			// System.out.println(children.get(children.size()-1));
		}
		if (b + 1 >= 0 && b + 1 < dim) {
			Board15P son = this.myClone();
			// System.out.println(son);
			son.setBoard(a, b + 1, '0');
			son.setBoard(a, b, this.board[a][b + 1]);
			// System.out.println(son);
			children.add(son);
			// System.out.println(children.get(children.size()-1));
		}

		return children;
	}

	/**
	 * Funcao para verificar se dois objetos da mesma classe sao iguais
	 * 
	 * @param l
	 * @return true caso sejam iguais. Caso contrario retorna false
	 */
	public boolean equals(Ilayout l) {
		// TODO Auto-generated method stub
		Board15P b = (Board15P) l;
		char a[][] = b.getBoard();
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
				if (this.board[i][j] != a[i][j]) {
					return false;
				}
			}
		}
		return true;
	}

	/*
	 * Funcao que cria um hashCode de cada objeto (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return this.toString().hashCode();
	}

	/**
	 * Funcao do Ilayout para verificar o objeto ee o objetivo
	 */
	@Override
	public boolean isGoal(Ilayout l) {
		// TODO Auto-generated method stub
		return this.equals(l);
	}

	/**
	 * Funcao do Ilayout para retornar o custo que � para ir desde o pai ao filho
	 */
	@Override
	public double getG() {
		// TODO Auto-generated method stub
		return 1;
	}

	/**
	 * Funcao para dar print ao objeto da forma desejada. Neste caso imprimi a
	 * disposicao do tabuleiro em uma string que contem por ordem os valores dessa
	 * matriz
	 */
	public String toString() {
		// TO BE COMPLETED
		String result = "";

		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
				if (board[i][j] == 0)
					result += " ";
				else
					result += board[i][j];
			}
			result += "\n";
		}
		return result;
	}

	/**
	 * Funcao que encontra um char especifico na matriz do objeto e retorna um array
	 * de tamanho dois. No primeiro indice esta o valor da linha que esse char foi
	 * encontrado e no segundo indice o valor da coluna.
	 * 
	 * @param x
	 * @return
	 */
	public int[] find(char x) {
		int a[] = new int[2];
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
				if (this.board[i][j] == x) {
					a[0] = i;
					a[1] = j;
					return a;
				}
			}
		}
		return a;
	}

	/**
	 * Funcao que faz o calculo do somatorio das distancias de manhattan para cada
	 * indice e retorna esse somatorio.
	 * 
	 * @param l - O Ilayout a que queremos comparar, ou seja o Board Goal
	 * @return sum - o somatorio dessas distancias
	 */
	public double sumOfTaxicab(Ilayout l) {
		int sum = 0;
		Board15P b = (Board15P) l;
		for (int i = 0; i < dim; i++) {
			for (int j = 0; j < dim; j++) {
			    	if(this.board[i][j]!='0') {
			    	    int a[] = b.find(this.board[i][j]);
			    	    sum += Math.abs(i - a[0]) + Math.abs(j - a[1]);
			    	}
			}
		}
		return sum;
	}
	
	public double misplacedPieces(Ilayout l) {
		int sum = 0;
		Board15P b = (Board15P) l;
		for(int i = 0;i<dim;i++) {
			for(int j=0;j<dim;j++) {
				if(this.board[i][j]!=b.board[i][j] && this.board[i][j]!='0')
					sum++;
			}
		}
		return sum;
	}

	/**
	 * Funcao do Ilayout para determinar e retornar o valor heuristico do objeto
	 */
	@Override
	public double getH(Ilayout l) {
		// TODO Auto-generated method stub
		if (this.h == -1) {
			//this.h = misplacedPieces(l);
			this.h = sumOfTaxicab(l);
		}
		return h;
	}

}
