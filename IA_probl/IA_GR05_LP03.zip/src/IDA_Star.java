import java.util.*;


/**
 * Classe para implementar o algoritmo IDS
 * 
 * @author GR05
 *
 */
public class IDA_Star {
	/**
	 * Os atributos da classe sera uma HashMap para conter os nos (States) ja
	 * visitados pelo algoritmo. E ainda dois interiros para saber quantos nos foram
	 * gerados e expandidos durante a execucao do algoritmo
	 */

	// private Map<String, State> fechados = new HashMap<>();
	private int newbound = Integer.MAX_VALUE;
	public long gerados = 0;
	public long expandidos = 0;

	/**
	 * A classe State ira representar cada no da arvore de procura
	 * 
	 * @author GR05
	 *
	 */
	static class State {
		// O objeto Ilayout que o no ira ter
		private Ilayout layout;
		// O pai deste no
		private State father;
		// A profundidade do no
		private double g;
		//
		private double h = -1;

		/**
		 * Construtor do State que dado um Ilayout l, e um State n cria um novo State,
		 * sendo l o atributo layout desse no e o n sera o pai desse o
		 * 
		 * @param l
		 * @param n
		 */
		public State(Ilayout l, State n) {
			layout = l;
			father = n;
			if (father != null)
				g = father.g + l.getG();
			else
				g = 0.0;
		}

		/**
		 * Funcao que da print ao State da forma desejada, neste caso o mesmo que o
		 * Ilayout em questao
		 */
		public String toString() {
			return layout.toString();
		}

		/**
		 * Retorna o atributo g do no (State)
		 * 
		 * @return g
		 */
		public double getG() {
			return g;
		}

		public double getH(Ilayout goal) {
			if (this.h == -1) {
				this.h = this.getLayout().getH(goal) + this.g;
				return this.h;
			} else
				return this.h;
		}

		/**
		 * Retorna o layout do State
		 * 
		 * @return layout
		 */
		public Ilayout getLayout() {
			return layout;
		}

		/**
		 * Retorna o pai desse State
		 * 
		 * @return father
		 */
		public State getFather() {
			return father;
		}

		/**
		 * Procura se numa determinada lista de States (dada pelo parametro da funcao)
		 * se o State (this) esta presente nela
		 * 
		 * @param list
		 * @return true caso esteja presente na lista, false caso contrario
		 */
		public boolean isHere(List<State> list) {
			for (State a : list) {
				if (a.getLayout().isGoal(this.getLayout())) {
					return true;
				}
			}
			return false;
		}
	}

	/**
	 * A partir de um State n, retorna uma lista de State em que dentro delas estao
	 * os filhos do State n.
	 * 
	 * @param n
	 * @return sucs - lista com os filhos de n
	 */
	final private Queue<State>  sucessores(State n, State goal) {
		Queue<State> sucs = new PriorityQueue<>(10, (s1, s2) -> (int) Math.signum(s1.getH(goal.getLayout()) - s2.getH(goal.getLayout())));
		//List<State> sucs = new ArrayList<>();
		List<Ilayout> children = n.layout.children();
		for (Ilayout e : children) {
			// if (n.father == null || !e.equals(n.father.layout)) {
			if (n.father == null || !e.isGoal(n.father.layout)) {
				State nn = new State(e, n);
				//System.out.println("filho gerado  "  + nn.getG() + "  " +nn.getH(goal.getLayout()));
				//System.out.println(nn);
				sucs.add(nn);
			}
		}
		return sucs;
	}

	/**
	 * Funcao que retorna uma lista por ordem desde o State que desejamos, ate ao
	 * State do topo da arvore. Assim teremos uma sequencia de States desde o State
	 * do topo da arvore ate ao State em questao
	 * 
	 * @param begin
	 * @return result - a lista com essa sequencia
	 */
	final private List<State> sequence(State begin) {
		State pre = begin;
		List<State> result = new ArrayList<>();
		while (pre != null) {
			result.add(0, pre);
			pre = pre.getFather();
		}
		return result;
	}

	/*
	 * Funcao que implementa e executa o algoritmo IDS. que deste um Ilayout src
	 * inicial, procura um caminho ate o Ilayout Goal. Neste caso ele faz a itera�ao
	 * ao DF /DLS
	 * 
	 * @param s - Ilayout que temos
	 * 
	 * @param goal - Ilayout que desejamos
	 * 
	 * @return Um Iterator<State> caso encontre a solucao com o caminho desde o s
	 * ate ao goal, caso contrario retorna null
	 */
	final public Iterator<State> ida_star(Ilayout src, Ilayout goal) {
		State stateGoal = new State(goal, null);
		State stateSrc = new State(src, null);
		int bound = (int) (stateSrc.getH(goal));
		ArrayList<State> path = new ArrayList<State>();
		while (true) {
			gerados++;
			System.out.println(bound);
			path.clear();
			path.add(stateSrc);
			State t = search(path, stateGoal, bound);
			//System.out.println(i++);
			if (t != null)
				return path.iterator();
			else if (t == null && newbound != Integer.MAX_VALUE) {
				bound = newbound;
				newbound = Integer.MAX_VALUE;
			} else
				return null;
		}

	}

	final public State search(ArrayList<State> path, State Goal, int bound) {
		//System.out.println(gerados + "    " + expandidos);
		State actual = path.get(path.size() - 1);
		//System.out.println(actual);
		double f = actual.getH(Goal.getLayout());
		if (actual.getLayout().isGoal(Goal.getLayout())) {
			return actual;
		} else if (f <= bound) {
			expandidos++;
			// System.out.println(actual + " " + actual.g + " " + actual.h);
			Queue<State> sucs = sucessores(actual, Goal);
			gerados += sucs.size();
			int sucs_size = sucs.size();
			for (int i = 0; i < sucs_size; i++) {
				State succ = sucs.poll();
				if (!succ.isHere(path)) {
					path.add(succ);
					//System.out.println("filho expandido  " + succ.getG() + "  " +succ.getH(Goal.getLayout()));
					//System.out.println(succ);
					State t = search(path, Goal, bound);
					if (t != null) {
						return t;
					}
					path.remove(path.size() - 1);
				}
			}
		}
		else if(f>bound && f<newbound) {
			newbound= (int) f;
			return null;
		}
		return null;
	}

}
