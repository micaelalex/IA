import static org.junit.Assert.*;

import java.util.*;

import org.junit.Test;

public class unitTests {

	@Test
	public void testCalculeFitness() {
		//fail("Not yet implemented");
		Random r = new Random(0);
		List<City> l = new ArrayList<>();
		l.add(new City(0, 0, 0));
		l.add(new City(1,4, 0));
		l.add(new City(2,4, 4));
		l.add(new City(3,0, 4));
		Chromosome c = new Chromosome(l,r);
		assertEquals(25, c.getFitness(), 0.001);
		
	}
	
	@Test
	public void testGetDistance() {
		//fail("Not yet implemented");
		City a = new City(0, 0, 0);
		City b = new City(1,3, 4);
		double dist = a.getDistance(b);
		assertEquals(5, dist, 0.001);
	}
	
	@Test
	public void testSwappingMutation() {
		//fail("Not yet implemented");
		Random r = new Random(0);
		double pm = 0.8;
		String obj ="1\n0\n2\n3\n";
		
		List<City> l = new ArrayList<>();
		l.add(new City(0, 0, 0));
		l.add(new City(1,4, 0));
		l.add(new City(2,4, 4));
		l.add(new City(3,0, 4));
		Chromosome c = new Chromosome(l,r);
		Chromosome cd = c.swappingMutation(pm);
		String result = "";
		for(City city : cd.getChromosome()) {
			result+= city.getID()+"\n";
		}
		assertEquals(obj,result);
	}
	
	@Test
	public void testOrder1Crossover() {
		//fail("Not yet implemented");
		Random r = new Random(0);

		String obj1 ="4 3 0 1 2 ";
		String obj2 ="2 0 3 1 4 ";
		
		List<City> l1 = new ArrayList<>();
		l1.add(new City(0, 0, 0));
		l1.add(new City(1,4, 0));
		l1.add(new City(2,4, 4));
		l1.add(new City(3,0, 4));
		l1.add(new City(4,10, 4));
		Chromosome c1 = new Chromosome(l1,r);
		
		List<City> l2 = new ArrayList<>();
		l2.add(new City(3,0, 4));
		l2.add(new City(1,4, 0));
		l2.add(new City(4,10, 4));
		l2.add(new City(0, 0, 0));
		l2.add(new City(2,4, 4));
		Chromosome c2 = new Chromosome(l2,r);
		
		List<City> l3 = new ArrayList<>();
		l3.add(new City(4,10, 4));
		l3.add(new City(0, 0, 0));
		l3.add(new City(2,4, 4));
		l3.add(new City(3,0, 4));
		l3.add(new City(1,4, 0));
		Chromosome c3 = new Chromosome(l3,r);
		
		List<City> l4 = new ArrayList<>();
		l4.add(new City(3,0, 4));
		l4.add(new City(4,10, 4));
		l4.add(new City(1,4, 0));
		l4.add(new City(0, 0, 0));
		l4.add(new City(2,4, 4));
		Chromosome c4 = new Chromosome(l4,r);
		
		List<Chromosome> lc = new ArrayList<>();
		lc.add(c1);
		lc.add(c2);
		lc.add(c3);
		lc.add(c4);
		Population p = new Population(lc,r,0);
		
		String sr1 ="";
		String sr2 ="";
		List<Chromosome> test = p.order1Crossover(c1, c2);
		for(City city : test.get(0).getChromosome())
			sr1 += city.getID() + " ";
		for(City city : test.get(1).getChromosome())
			sr2 += city.getID() + " ";
		
		assertEquals(obj1,sr1);
		assertEquals(obj2,sr2);
	}
	
	@Test
	public void testTournamentSelection() {
		//fail("Not yet implemented");
		Random r = new Random(0);
		String obj ="0 1 2 3 ";
		int s = 4;
		
		List<City> l1 = new ArrayList<>();
		l1.add(new City(0, 0, 0));
		l1.add(new City(1,4, 0));
		l1.add(new City(2,4, 4));
		l1.add(new City(3,0, 4));
		Chromosome c1 = new Chromosome(l1,r);
		
		List<City> l2 = new ArrayList<>();
		l2.add(new City(3,0, 4));
		l2.add(new City(1,4, 0));
		l2.add(new City(0, 0, 0));
		l2.add(new City(2,4, 4));
		Chromosome c2 = new Chromosome(l2,r);
		
		List<City> l3 = new ArrayList<>();
		l3.add(new City(0, 0, 0));
		l3.add(new City(2,4, 4));
		l3.add(new City(3,0, 4));
		l3.add(new City(1,4, 0));
		Chromosome c3 = new Chromosome(l3,r);
		
		List<City> l4 = new ArrayList<>();
		l4.add(new City(3,0, 4));
		l4.add(new City(1,4, 0));
		l4.add(new City(0, 0, 0));
		l4.add(new City(2,4, 4));
		Chromosome c4 = new Chromosome(l4,r);
		
		List<Chromosome> lc = new ArrayList<>();
		lc.add(c1);
		lc.add(c2);
		lc.add(c3);
		lc.add(c4);
		Population p = new Population(lc,r,0);
		List<Chromosome> test = p.tournamentSelection(s);
		
		String sr ="";
		for(City c : test.get(0).getChromosome()) {
			sr+= c.getID()+" ";
		}
		System.out.println(sr);
		
		assertEquals(obj,sr);
		
	}

}
