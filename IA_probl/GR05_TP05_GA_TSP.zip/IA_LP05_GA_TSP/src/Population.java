import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Classe que representa a Populacao de Chromosomes e que contem os metodos
 * necessarios para o desenvolvimento do GA.
 */
public class Population {
	/**
	 * Atributo que representa todos os individos da populacao, ou seja, uma lista
	 * com os Chromosomes desta populacao.
	 */
	private List<Chromosome> population;
	/**
	 * Atributo que representa o gerador Random desta Population.
	 */
	private Random generator;
	/**
	 * Atributo que representa o numero da geracao deste Population.
	 */
	private int generation;

	/**
	 * Construtor da classe que dado apenas um Random r como parametro cria uma nova
	 * Population, com uma lista vazia e com o generation igual a zero.
	 * 
	 * @param r - Random que ira ser o gerador de Randoms da Population.
	 */
	public Population(Random r) {
		population = new ArrayList<Chromosome>();
		generator = r;
		generation = 0;
	}

	/**
	 * Construtor da classe que dado como parametros uma lista de Chromosomes, um
	 * Random r e um inteiro gen cria uma nova Population, em que estes parametros
	 * serao os atributos desta.
	 * 
	 * @param popu - Lista com os Chromosomes.
	 * @param r    - Random que ira ser o gerador de Randoms da Population.
	 * @param gen  - Numero da geracao da Population.
	 */
	public Population(List<Chromosome> popu, Random r, int gen) {
		population = popu;
		generator = r;
		generation = gen;
	}

	/**
	 * Metodo que ira criar uma populacao aleatoria. O metodo recebe como parametros
	 * um int n, que ira ser o tamanho da populacao, um uma lista com todas as
	 * cidades possiveis para os futuros Chromosomes, e um Random r que ir� ser o
	 * gerador de randoms desta nova Population. Esta funcao cria Chromosomes random
	 * e adiciona a uma lista, em que depois cria uma nova Population com a lista e
	 * o Random r.
	 * 
	 * @param n      - tamanho da populacao
	 * @param cities - lista com todas as cidades possiveis para o Chromosome
	 * @param r      - O gerador Random.
	 * @return new Population - A nova Population criada aleatoriamente.
	 */
	public static Population generateRandomPopulation(int n, List<City> cities, Random r) {
		List<Chromosome> pop = new ArrayList<Chromosome>();
		for (int i = 0; i < n; i++) {
			pop.add(Chromosome.generateRandomChromosome(cities, r));
		}
		return new Population(pop, r, 0);

	}

	/**
	 * Funcao que calcula e imprime o fitness medio desta Population. Esta funcao
	 * tambem imprime o valor do fitness mais baixo e o mais alto encontrado pela
	 * Population.
	 */
	public void getAverageFitness() {
		double sum = 0;
		double min = Double.MAX_VALUE;
		Chromosome mn = null;
		;
		double max = Double.MIN_VALUE;
		Chromosome mx = null;
		for (Chromosome c : population) {
			sum += c.getFitness();
			if (c.getFitness() > max) {
				max = c.getFitness();
				mx = c;
			}
			if (c.getFitness() < min) {
				min = c.getFitness();
				mn = c;
			}
		}
		sum = sum / population.size();
		System.out.println("Min: " + min);
		System.out.println("Average=" + sum);
		System.out.println("Max: " + max);

	}

	/**
	 * Funcao que pratica o order1Crossover por toda a polulacao, ou seja por toda a
	 * lista de Chromosomes. Recebe como parametro um double que ira ser a
	 * probabilidade de crossover
	 * 
	 * @param pc - Probabilidade de crossover.
	 * @return newPopulation - Lista de os novos Chromosomes depois do crossover.
	 */
	public List<Chromosome> order1CrossoverByPopulation(double pc) {
		List<Chromosome> newPopulation = new ArrayList<Chromosome>();

		for (int i = 0; i < population.size(); i += 2) {
			double u = generator.nextDouble();
			if (u < pc) {
				newPopulation.addAll(this.order1Crossover(population.get(i), population.get(i + 1)));
			} else {
				newPopulation.add(population.get(i));
				newPopulation.add(population.get(i + 1));
			}
		}

		return newPopulation;
	}

	/**
	 * Funcao que aplica o order1Crossover entre dois Chromosomes, com uma pequena
	 * diferenca. Neste caso como estamos a resolver para o problema TSP, nos
	 * sabemos que nao importanta onde comecamos, porque vamos voltar sempre para o
	 * inicio, ou seja o fitness nao muda se dermos shiff a de como a lista esta.
	 * Assim geramos dois valores para determinar os dois pontos (min e max) que ira
	 * haver a troca de cidades (genes). E a grande diferenca ee que metemos essa
	 * troca no inicio dos novos filhos (lista de cidades que mais tarde iremos
	 * usa-los para criar os novos Chromosomes. De resto aplica-se o algoritmo
	 * conhecido.
	 * 
	 * @param c1 - O primeiro pai Chromosome.
	 * @param c2 - O segundo pai Chromosome.
	 * @return newpop - Uma nova lista com os dois Chromosomes filhos criados.
	 */
	public List<Chromosome> order1Crossover(Chromosome c1, Chromosome c2) {
		List<Chromosome> newpop = new ArrayList<Chromosome>();
		double u1 = generator.nextDouble();
		int point1 = 1 + Math.toIntExact(Math.round(u1 * (population.get(0).getChromosome().size() - 2)));
		double u2 = generator.nextDouble();
		int point2 = 1 + Math.toIntExact(Math.round(u2 * (population.get(0).getChromosome().size() - 2)));

		int max;
		int min;
		if (point1 < point2) {
			min = point1;
			max = point2;
		} else {
			min = point2;
			max = point1;
		}

		 //System.out.println(c1);
		 //System.out.println(c2);
		 //System.out.println(min + " " + max);

		List<City> son1 = new ArrayList<City>();
		List<City> son2 = new ArrayList<City>();

		son1.addAll(c2.getChromosome().subList(min, max));
		son2.addAll(c1.getChromosome().subList(min, max));

		int j = max;
		while (j != min) {
			boolean contains = false;
			City test = c1.getChromosome().get(j);
			for(int i =0;i<son1.size();i++)
				if(son1.get(i).equals(test)) {
					contains = true;
					break;
				}
			if (!contains)
				son1.add(test);
			if (j == c1.getChromosome().size() - 1)
				j = 0;
			else
				j++;
		}

		j = max;
		while (j != min) {
			boolean contains = false;
			City test = c2.getChromosome().get(j);
			for(int i =0;i<son2.size();i++)
				if(son2.get(i).equals(test)) {
					contains = true;
					break;
				}
			if (!contains)
				son2.add(test);
			if (j == c2.getChromosome().size() - 1)
				j = 0;
			else
				j++;
		}
		
		//System.out.println(son1);
		//System.out.println(son2);

		for (int i = 0; i < c1.getChromosome().size(); i++) {
			boolean contains = false;
			City test = c1.getChromosome().get(i);
			for(int m =0;m<son1.size();m++)
				if(son1.get(m).equals(test)) {
					contains = true;
					break;
				}
			if (!contains)
				son1.add(test);	
			//if (!son1.contains(c1.getChromosome().get(i)))
			//	son1.add(c1.getChromosome().get(i));
		}

		for (int i = 0; i < c2.getChromosome().size(); i++) {
			boolean contains = false;
			City test = c2.getChromosome().get(i);
			for(int m =0;m<son2.size();m++)
				if(son2.get(m).equals(test)) {
					contains = true;
					break;
				}
			if (!contains)
				son2.add(test);	
			
			//if (!son2.contains(c2.getChromosome().get(i)))
			//	son2.add(c2.getChromosome().get(i));
		}

		newpop.add(new Chromosome(son1, this.generator));
		newpop.add(new Chromosome(son2, this.generator));

		//System.out.println(newpop);

		return newpop;
	}

	/**
	 * Funcao que aplica o "Generation Replacement" pela Population. Esta funcao
	 * recebe como parametro, um inteiro s que ira ser o tamanho do torneio, um
	 * double pc que ira ser a probabilidade de crossover e outro double pm que ira
	 * ser a probabilidade de mutacao. Aqui s�o aplicados Tournament Selection
	 * Without Replacement, o Swapping Mutation e o Order 1 Crossover, em que no
	 * final de cada um a lista de chromosomes ee atualizada. E no final a geracao
	 * incrementa 1 valor.
	 * 
	 * @param s  - Tamanho do torneio.
	 * @param pc - Probabilidade de crossover.
	 * @param pm - Probabilidade de mutacao
	 */
	public void generationalReplacement(int s, double pc, double pm) {
		this.population = this.tournamentSelectionWithoutReplacement(s);
		this.population = this.order1CrossoverByPopulation(pc);
		this.population = this.swappingMutationOverPopulation(pm);
		this.generation++;
	}

	/**
	 * Funcao que recebe como parametro um inteiro s, o tamanho do torneio e aplica
	 * o Tournament Selection Without Replacement e retorna uma nova lista de
	 * Chromosomes.
	 * 
	 * @param s - Tamanho do torneio
	 * @return winners - Nova lista de Chromosomes depois de realizado o torneio.
	 */
	public List<Chromosome> tournamentSelectionWithoutReplacement(int s) {
		List<Chromosome> winners = new ArrayList<Chromosome>();

		for (int i = 0; i < s; i++) {
			// System.out.println("aaaa");
			Population newPopulation = new Population(this.RandomPermutation(), this.generator, this.generation);
			// System.out.println("bbb");
			// System.out.println(newPopulation);
			List<Chromosome> result = newPopulation.tournamentSelection(s);

			for (int j = 0; j < result.size(); j++)
				winners.add(result.get(j));
		}

		return winners;
	}

	/**
	 * Funcao que aplica a Random Permutation.
	 * 
	 * @return newPopulation - Nova lista depois de realizada a permuta��o entre os
	 *         Chromosomes.
	 */
	public List<Chromosome> RandomPermutation() {
		List<Chromosome> newPopulation = new ArrayList<Chromosome>();

		for (int i = 0; i < population.size(); i++) {
			newPopulation.add(population.get(i));
		}

		// System.out.println("Criou a nova population");

		for (int m = 0; m < newPopulation.size() - 1; m++) {
			// System.out.println(m);
			double u = generator.nextDouble();
			// System.out.println("u: " + u);
			int j = Math.toIntExact(m + Math.round(u * (newPopulation.size() - 1 - m)));
			// System.out.println("j: " + j);
			Chromosome value = newPopulation.get(m);
			newPopulation.set(m, newPopulation.get(j));
			newPopulation.set(j, value);
		}

		// System.out.println("saio disto?");

		return newPopulation;
	}

	/**
	 * Funcao que dado como parametro um inteiro s, aplica o Tournament Selection
	 * pela lista de Chromosomes da Population.
	 * 
	 * @param s - Tamanho do torneio.
	 * @return winners - Lista de Chromosomes selecionados pelo torneio.
	 */
	public List<Chromosome> tournamentSelection(int s) {
		List<Chromosome> winners = new ArrayList<Chromosome>();

		for (int i = 0; i < population.size(); i += s) {
			Chromosome bestFitness = population.get(i);
			for (int j = i; j < i + s; j++) {
				if (population.get(j).getFitness() > bestFitness.getFitness()) {
					bestFitness = population.get(j);
				}
			}
			winners.add(bestFitness);
		}

		return winners;
	}

	/**
	 * Funcao que permite representar o objeto de Population em String. Neste caso
	 * dados print a todos os valores presentes no na lista de Chromosomes da
	 * Population.
	 */
	public String toString() {
		String result = "";
		for (Chromosome c : population) {
			result += c.toString();
		}
		return result;
	}

	/**
	 * Funcao que dado um double pm (probabilidade de mutacao) como parametro
	 * permite realizar o Swapping Mutation por toda a populacao, ou seja, toda a
	 * lista de Chromosomes da Population.
	 * 
	 * @param pm - probabilidade de mutacao
	 * @return - Nova lista de Chromosomes depois de realizada a swapping mutation
	 *         pela populacao
	 */
	public List<Chromosome> swappingMutationOverPopulation(double pm) {
		List<Chromosome> newPopulation = new ArrayList<Chromosome>();

		for (int i = 0; i < this.population.size(); i++) {
			newPopulation.add(this.population.get(i).swappingMutation(pm));
		}

		return newPopulation;
	}

	/**
	 * Funcao que retorna o Chromosome com melhor fitness da Population.
	 * 
	 * @return mx - Chromosome com melhor fitness desta Population.
	 */
	public Chromosome getBestChromosome() {
		double max = Double.MIN_VALUE;
		Chromosome mx = null;
		for (Chromosome c : population) {

			if (c.getFitness() > max) {
				max = c.getFitness();
				mx = c;
			}
		}
		return mx;
	}

	/**
	 * Permite dar print das coordenades cartesianas das cidades pela ordem que
	 * estao no Chromosome com melhor fitness.
	 */
	public void orderGraphPrint() {
		Chromosome b = this.getBestChromosome();
		System.out.println("X	Y");
		for (City c : b.getChromosome()) {
			System.out.println(c.getX() + "	" + c.getY());
		}
	}

}
