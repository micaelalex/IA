import java.io.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;

/**
 * Classe que ira represtar a main/client deste problema.
 */
public class Main {

	/**
	 * Funcao main em que ira ler da consola um inteiro n para o tamanho da populacao, um inteiro l para numero de cidades que o Chromosome ira ter,
	 * um inteiro s para o tamanho do torneio, um double pm para a probabilidade de mutacao, um pc para a probabilidade de crossover e por fim ira receber um inteiro g que ira ser o numero de geracoes que iremos ter.
	 * Depois de ler tudo o que necessita, irao ser geradas aleatoriamente cidades e guardadas numa lista.
	 * Depois e gerada uma Population aleatoriamente com as cidades geradas e a partir dessa Population iremos aplicar
	 * o GA desenvolvido.
	 * Iremos dar print do Chromosome com melhor fitness da ultima geracao  (coordenadas cartesianas pela ordem correta)
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Random generator = new Random(0);
		
		/*
		DecimalFormatSymbols unusualSymbols = new DecimalFormatSymbols();
		unusualSymbols.setDecimalSeparator('.');
		DecimalFormat df = new DecimalFormat("0.00", unusualSymbols);
		*/ 
		
		int n = sc.nextInt();
		int l = sc.nextInt();
		int s = sc.nextInt();
		double pm = Double.parseDouble(sc.next());
		double pc = Double.parseDouble(sc.next());
		int g = sc.nextInt();

		
		List<City> cities = new ArrayList<>();
		for(int i=0;i<l;i++) {
			double x = generator.nextDouble()*200;
			double y = generator.nextDouble()*200;
			cities.add(new City(i,x,y));
		}
		
		/*
		for(City c : cities) {
			System.out.println(c);
		}
		*/
		
		Population zero = Population.generateRandomPopulation(n, cities, generator);
		//System.out.println("\nPopula��o 0");
		zero.getAverageFitness();
		
		//System.out.println(zero);
		
		for(int j=1; j<=g; j++) {
			zero.generationalReplacement(s, pc, pm);
			//System.out.println("Popula��o "+ j +": ");
			if(j==g/2)
				zero.getAverageFitness();
			//System.out.println(zero);
		}
		
		zero.getAverageFitness();
		
		/*for(City c : cities) {
			System.out.println(c);
		}*/
		
		//zero.orderGraphPrint();
		
	}

}
