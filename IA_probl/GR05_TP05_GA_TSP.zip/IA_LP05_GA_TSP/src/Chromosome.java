import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Classe que ira representar um Chromosome, em que os genes serao as cidades
 * que a percorrer pela ordem que sao apresentadas. Esta classe ira tambem ter
 * alguns metodos essenciais para o desenvolvimento do GA.
 *
 */
public class Chromosome {
	/**
	 * Atributo que representa a lista que contem as cidades pela ordem que teremos
	 * de percorrer.
	 */
	private List<City> chromosome;
	/**
	 * Atributo do gerador "random".
	 */
	private Random generator;
	/**
	 * Atributo que representa o fitness deste chromosome.
	 */
	double fitness;

	/**
	 * Contrutor da classe que dado apenas um Random r, como parametro cria um novo
	 * Chromosome. O fitness ee calculado automaticamente pelo metodo
	 * calculateFitness.
	 * 
	 * @param r - Random que ira ser o generator do chromosome.
	 */
	public Chromosome(Random r) {
		chromosome = new ArrayList<City>();
		generator = r;
		this.calculateFitness();
	}

	/**
	 * Construtor da classe que dado uma lista com as cidades e um Random como
	 * parametros cria um novo Chromosome O fitness ee calculado automaticamente
	 * pelo metodo calculateFitness.
	 * 
	 * @param chromo - Lista de cidades que ira ser o atributo chromosome do
	 *               Chromosome
	 * @param r      - Random que ira ser o atributo generator deste Chromosome.
	 */
	public Chromosome(List<City> chromo, Random r) {
		chromosome = chromo;
		generator = r;
		this.calculateFitness();
	}

	/**
	 * Funcao que retorna o atributo fitness deste Chromosome
	 * 
	 * @return this.fitness
	 */
	public double getFitness() {
		return fitness;
	}

	/**
	 * Funcao que retorna o atributo chromosome (lista de cidades) deste Chromosome
	 * 
	 * @return this.chromosome
	 */
	public List<City> getChromosome() {
		return chromosome;
	}

	/**
	 * Funcao que ira calcular o fitness do Chromosome e ira defini-lo como
	 * atributo. O fitness ira 100 a multiplicar pelo numero de cidades do
	 * chromosome a dividir pelo sumatorio entre as distancias entre as varias
	 * cidades pela ordem dada pela lista. Isto inclui-o a distancia entre a ultima
	 * cidade e a primeira da lista, pois neste problema teremos que voltar ao
	 * inicio.
	 */
	public void calculateFitness() {
		double sum = 0;
		for (int i = 0; i <= chromosome.size() - 2; i++) {
			sum += chromosome.get(i).getDistance(chromosome.get(i + 1));
		}
		sum += chromosome.get(0).getDistance(chromosome.get(chromosome.size() - 1));
		fitness = 100 * chromosome.size() / sum;
	}

	/**
	 * Funcao que dado dois parametros, uma lista com todas as cidades possiveis
	 * para o os genes e um Random r, ira construir um Chromosome aleatorio. Ele
	 * copia os valores da lista dada como parametro para uma nova lista e baralha
	 * esta lista com Collections.shuffle. Depois cria um novo Chromosome com essa
	 * lista baralhada e com o Random r.
	 * 
	 * @param possible - Lista com todas as cidades possiveis
	 * @param r        - Random que ira ser o gerador de numeros aleatorios.
	 * @return new Chromosome - O Chromosome gerado com a lista baralhada e com o
	 *         Random r
	 */
	public static Chromosome generateRandomChromosome(List<City> possible, Random r) {
		List<City> chromosome = new ArrayList<>();
		chromosome.addAll(possible);

		Collections.shuffle(chromosome);

		return new Chromosome(chromosome, r);
	}

	/**
	 * Funcao que aplica o swappingMutation, ou seja, caso ha-ja mutation ele troca
	 * duas cidades entre si. Para haver swappingMutation ee preciso gerar um numero
	 * double, com o this.generator e verificar se este ee menor do que a
	 * probabilidade pm dada como parametro da funcao. Se assim for, gera-se outro
	 * numero e converte-se este para um index entre 0 e o tamanho da lista do
	 * Chromosome - 1. Assim obtemos que cidade iremos trocar com o individuo do
	 * ciclo for.
	 * 
	 * @param pm - probabilidade de mutacao
	 * @return new Chromosome - retorna um novo chromosome, independentemente se
	 *         este teve mutacao ou nao.
	 */
	public Chromosome swappingMutation(double pm) {
		List<City> newchromosome = new ArrayList<City>();
		newchromosome.addAll(chromosome);
		for (int i = 0; i < newchromosome.size(); i++) {
			double r = generator.nextDouble();
			if (pm > r) {
				int point = Math.toIntExact(Math.round(generator.nextDouble() * (newchromosome.size() - 1)));
				Collections.swap(newchromosome, i, point);
			}
		}
		return new Chromosome(newchromosome, generator);
	}

	/**
	 * Funcao para representar o objeto de Chromosome numa String Neste caso iremos ter nessa
	 * string, todos os valores da lista chromosome, e no final teremos o fitness
	 * deste Chromosome.
	 */
	public String toString() {
		String result = "[";
		for (City c : chromosome)
			result += c.getID() + " ";
		return result + "] fitness=" + this.fitness + "\n";
	}

}
