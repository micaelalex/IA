/**
 * Esta classe ira representar uma cidade, ou seja, tera os atributos referentes
 * a esta. Consequentemente, ira ter tambem os setters e getters dos atribubutos
 * e ainda a funcao toString.
 */
public class City {
	/**
	 * Atributo que identifica cada cidade uma da outra
	 */
	private int id;
	/**
	 * Atributos que representam as coordenadas x e y no sistema de coordenades
	 * cartesianas
	 */
	private double x, y;

	/**
	 * Construtor da classe City, em que este recebe um int id, e dois doubles, x e
	 * y.
	 * 
	 * @param id - identificador da cidade
	 * @param x  - coordenada x
	 * @param y  - coordenade y
	 */
	public City(int id, double x, double y) {
		this.id = id;
		this.x = x;
		this.y = y;
	}

	/**
	 * Funcao para retornar o id da cidade
	 * 
	 * @return this.id
	 */
	public int getID() {
		return id;
	}

	/**
	 * Funcao para retornar o x desta cidade
	 * 
	 * @return this.x
	 */
	public double getX() {
		return x;
	}

	/**
	 * Funcao para retornar o y desta cidade
	 * 
	 * @return this.y
	 */
	public double getY() {
		return y;
	}

	/**
	 * Funcao que calcula a distancia entre duas cidades, esta (this) e uma dada
	 * como parametro da funcao, City c. O calculo dessa funcao ee feita com o
	 * teorema de pitagoras. Retorna um double com a distancia entre essas cidades.
	 * 
	 * @param c - Cidade a que queremos calcular a distancia
	 * @return double - A distancia entre as cidades
	 */
	public double getDistance(City c) {
		return Math.sqrt(Math.pow(this.x - c.getX(), 2) + Math.pow(this.y - c.getY(), 2));
	}

	/**
	 * Funcao para representar o objeto numa string. Neste caso metemos todos os
	 * atributos nessa string.
	 * 
	 * @return String
	 */
	public String toString() {
		return "City " + id + ": X=" + x + " Y=" + y;
	}

	/**
	 * Funcao para comparar se duas cidades (a this e outra dada como parametro, c)
	 * sao iduais ou nao. Neste caso verificamos se todos os parametros sao iguais
	 * entre as cidades, mas podias so verificar se o ID ee igual.
	 * 
	 * @param c - Cidade a qual queremos comparar se sao iguais
	 * @return true - se todos os atributos entre as cidades forem iguais. false -
	 *         caso contrario.
	 */
	public boolean equals(City c) {
		if (this.id == c.id && this.x == c.x && this.y == c.y)
			return true;
		return false;
	}

}
