package TicTacToe;

import java.util.HashSet;
import java.util.Random;

public class ReactiveAgent {
	 private static int corners[] = {0,2,6,8};
	 
	 /**
	  * The "brain" of the Reactive Agent
	  * @param board 	the Tic Tac Toe board to play on
	  */
	 static void action(Board board) {
		int move = -1;
		move = possibleWin(board, Board.State.X);
		//nivel 0 - Verificar possivel vitoria
		if(move!= -1) {
			board.move(move);
		}
		else {
			//nivel 1 - Verificar possivel vitoria do oponente
			move = possibleWin(board, Board.State.O);
			if(move!= -1) {
				board.move(move);
			}
			else {
				//nivel 2 - Verificar se e o primeiro move
				if(isFirstMove(board)) {
					board.move(firstMove());
				}
				else {
					//nivel 3 - Se o centro estiver ocupado
					if(viewCenter(board, Board.State.O ) ) {
						board.move(completeDiagonal(board));
					}
					else {
						//nivel 4 -  preenche outro canto que esteja livre
						if(viewBox(board,8) || viewBox(board,0) || viewBox(board,2) || viewBox(board,6)) {
							board.move(anotherCorner(board));
						}
						//nivel 5 - jogada random
						else {
							board.move(randomMove(board));
						}
					}
				}
			}
		}
	}
	 
	 /**
	  * Get a first place Blank, we call the function randomMove bc I just need a place to play 
	  * @param board		the Tic Tac Toe board to play on
	  * @return return		the index off a blank place or -1 if the board dont have blank places.
	  */
	private static int randomMove(Board board) {
    	Board.State[][] board2 = board.toArray();
    	for(int i=0;i<3;i++) {
    		for(int j=0;j<3;j++) {
    			if(board2[i][j]==Board.State.Blank) {
    				return (i*3)+j;
    			}
    		}
    	}
		return -1;
	}
	
	/**
	 * Check if the place is blank (place = box )
	 * @param board		the Tic Tac Toe board to play on		
	 * @param i			the index of a place that we want to check
	 * @return true if the place is blank, otherwise false
	 */
	private static boolean viewBox(Board board, int i) {
		HashSet<Integer> freeMoves=board.getAvailableMoves();
		return freeMoves.contains(i);
	}
	
	/**
	 * Give another corner that we can play
	 * @param board		the Tic Tac Toe board to play on
	 * @return the index of the corner to play
	 */
	private static int anotherCorner(Board board) {
		HashSet<Integer> freeMoves=board.getAvailableMoves();
		Board.State[][] board2 = board.toArray();
		if(board2[2][0]==Board.State.X) {
			return betterCorner(freeMoves, 2*3+0);
		}
		if(board2[0][2]==Board.State.X) {
			return betterCorner(freeMoves, 0*3+2);
		}
		if(board2[2][2]==Board.State.X) {
			return betterCorner(freeMoves, 2*3+2);
		}
		if(board2[0][0]==Board.State.X) {
			return betterCorner(freeMoves, 0*3+0);
		}
			return randomCorners();
	}
	
	/**
	 * Give the better corner to play taking into account the board (the availables moves), and the corners with agent move 
	 * @param freeMoves		the availables moves in the board
	 * @param i				the index of a corner with a agent move
	 * @return	the index of the better corner to play
	 */
	private static int betterCorner(HashSet<Integer> freeMoves, int i) {
		if(i==8) {
			if(freeMoves.contains(2)) {
				if(freeMoves.contains(1) && freeMoves.contains(5))
					return 2;
			}
			if(freeMoves.contains(6)) {
				if(freeMoves.contains(3) && freeMoves.contains(7))
					return 6;
			}
			if(freeMoves.contains(0)) {
				if(freeMoves.contains(1) && freeMoves.contains(3))
					return 0;
			}
		}
		
		if(i == 6) {
			if(freeMoves.contains(8)) {
				if(freeMoves.contains(7) && freeMoves.contains(5))
					return 8;
			}
			if(freeMoves.contains(0)) {
				if(freeMoves.contains(1) && freeMoves.contains(3))
					return 0;
			}
			if(freeMoves.contains(2)) {
				if(freeMoves.contains(1) && freeMoves.contains(5))
					return 2;
			}
		}
		
		if(i == 2) {
			if(freeMoves.contains(8)) {
				if(freeMoves.contains(7) && freeMoves.contains(5))
					return 8;
			}
			if(freeMoves.contains(0)) {
				if(freeMoves.contains(1) && freeMoves.contains(3))
					return 0;
			}
			if(freeMoves.contains(6)) {
				if(freeMoves.contains(3) && freeMoves.contains(7))
					return 6;
			}	
		}
		
		if(i == 0) {
			if(freeMoves.contains(2)) {
				if(freeMoves.contains(1) && freeMoves.contains(5))
					return 2;
			}
			if(freeMoves.contains(6)) {
				if(freeMoves.contains(3) && freeMoves.contains(7))
					return 6;
			}
			if(freeMoves.contains(8)) {
				if(freeMoves.contains(7) && freeMoves.contains(5))
					return 0;
			}	
		}
		return -1;
	}
	
	/**
	 * View if the center has a state s
	 * @param board 	the Tic Tac Toe board to play on
	 * @param s			the state that we want to check if the center is fill with it
	 * @return true if the center have that state, otherwise false
	 */
	private static boolean viewCenter(Board board, Board.State s) {
    	Board.State[][] board2 = board.toArray();
    	if(board2[1][1]==s)
    		return true;
    	else
    		return false;
	}
	
	/**
	 * Check if the player that plays with a state s can win the game with one more move
	 * @param board		the Tic Tac Toe board to play on
	 * @param s			the state of a player
	 * @return true if is possible, otherwise false 
	 */
	private static int possibleWin(Board board, Board.State s ) {
		int result;
		if( (result = checkColumns(board,s))!=-1) {
			//System.out.println("Coluna");
			return result;
		}
		else if ( (result = checkRows(board,s))!=-1) {
			//System.out.println("Linha");
			return result;
		}
		else if ( (result = checkDiagonalLtoR(board,s))!=-1) {
			//System.out.println("Dia LR");
			return result;
		}
		else if ( (result = checkDiagonalRtoL(board,s))!=-1) {
			//System.out.println("Dia RL");
			return result;
		}
		else
			return -1;
	}
	
	/**
	 * Check all columns if they one have a place with 2 states s and one place with state blank
	 * @param board 	the Tic Tac Toe board to play on
	 * @param s			the state that we want to check
	 * @return return the index of a place that have a black state if exist, otherwise -1
	 */
    private static int checkColumns (Board board, Board.State s) {
    	Board.State[][] board2 = board.toArray();

    	for(int i=0; i<3;i++) {
    		for (int j=0;j<3;j++) {
    			if(board2[j][i]==Board.State.Blank && board2[(j+1)%3][i]==s && board2[(j+2)%3][i]== s ) {
    				return ((j*3)+i);
    			}
    		}
    	}
    	return -1;
    }


    
    /**
     * Check all rows if they have 2 places with states s and one place with a blank state 
     * @param board		the Tic Tac Toe board to play on
     * @param s			the state that we want to check
     * @return return the index of a place that have a black state if exist, otherwise -1
     */
    private static int checkRows (Board board, Board.State s) {
    	Board.State[][] board2 = board.toArray();

    	for(int i=0; i<3;i++) {
    		for (int j=0;j<3;j++) {
    			if(board2[i][j]==Board.State.Blank && board2[i][(j+1)%3]==s && board2[i][(j+2)%3]== s ) {
    				return ((i*3)+j);
    			}
    		}
    	}
    	return -1;
    }
    
    /**
     * Check the LeftToRight Diagonal if they have 2 places with states s 
     * and one place with a blank state 
     * @param board 	the Tic Tac Toe board to play on
     * @param s			the state that we want to check
     * @return	return the index of a place that have a black state if exist, otherwise -1
     */
    private static int checkDiagonalLtoR(Board board, Board.State s) {
    	Board.State[][] board2 = board.toArray();
    	if(board2[0][0]==Board.State.Blank && board2[1][1]==s && board2[2][2]== s ) {
    		return ((0*3)+0);
    	}
    	else if(board2[1][1]==Board.State.Blank && board2[0][0]==s && board2[2][2]== s ) {
    		return ((1*3)+1);
    	}
    	else if(board2[2][2]==Board.State.Blank && board2[1][1]==s && board2[0][0]== s ) {
    		return ((2*3)+2);
    	}
    	return -1;
    }
    
    /**
     * Check the RightToLeft Diagonal if they have 2 places with states s 
     * and one place with a blank state 
     * @param board 	the Tic Tac Toe board to play on
     * @param s			the state that we want to check
     * @return	return the index of a place that have a black state if exist, otherwise -1
     */
    private static int checkDiagonalRtoL(Board board, Board.State s) {
    	Board.State[][] board2 = board.toArray();

    	if(board2[0][2]==Board.State.Blank && board2[1][1]==s && board2[2][0]== s ) {
    		return ((0*3)+2);
    	}
    	else if(board2[1][1]==Board.State.Blank && board2[0][2]==s && board2[2][0]== s ) {
			return ((1*3)+1);
    	}
    	else if(board2[2][0]==Board.State.Blank && board2[1][1]==s && board2[0][2]== s ) {
			return ((2*3)+0);
    	}

    	return -1;
    }

    /**
     * Check if the board is empty (just have blank states), that give to agent the information if 
     * he is the first "player" to play 
     * @param board		the Tic Tac Toe board to play on
     * @return true if that is verified, otherwise false
     */
	private static boolean isFirstMove(Board board) {
		boolean result = true;
    	Board.State[][] board2 = board.toArray();
    	for(int i=0;i<3;i++) {
    		for (int j =0;j<3;j++) {
    			if(board2[i][j]!=Board.State.Blank)
    				return false;
    		}
    	}
		return result;
	}
	
	/**
	 * Give 1 of a 4 corners of the board
	 * @return the index of a corner
	 */
	private static int randomCorners() {
		Random rand = new Random();
		return corners[rand.nextInt(4)];
	}
	
	/**
	 * Give a place to play the first move
	 * @return the index of a place
	 */
	private static int firstMove() {
		return randomCorners();
	}
	
	
	/**
	 * Give us a corner that will complete one diagonal
	 * @param board 	the Tic Tac Toe board to play on
	 * @return the index of the corner
	 */
	private static int completeDiagonal( Board board) {
    	Board.State[][] board2 = board.toArray();
    	if(board2[2][0]==Board.State.X && board2[0][2]==Board.State.Blank)
    		return 2;
    	else if (board2[0][2]==Board.State.X && board2[2][0]==Board.State.Blank)
    		return 6;
    	else if (board2[0][0]==Board.State.X && board2[2][2]==Board.State.Blank)
    		return 8;
    	else 
    		return 0;
	}
}
